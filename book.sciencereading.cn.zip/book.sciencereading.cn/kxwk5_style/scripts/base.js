//当滚动条的位置处于距顶部100像素以下时，跳转链接出现，否则消失  
$(function() {  
    var test = function() {
        alert(123);
    };
	//控制返回首页显示隐藏
    $(window).scroll(function(){  
        if ($(window).scrollTop()>100){  
            $("#back-to-top").fadeIn(500);  
        }  
        else  
        {  
            $("#back-to-top").fadeOut(500);  
        }  
    });  

    //当点击跳转链接后，回到页面顶部位置  
    $("#back-to-top").click(function(){   
		if($('html').scrollTop()) {  
	        $('html').animate({ scrollTop: 0 }, 1000);  
	        return false;  
	    }  
	    $('body').animate({ scrollTop: 0 }, 1000);  
         return false;              
    });
    
    //点击切换搜索类型
    $("#header").delegate(".search_type","click",function(){ 
    	var type = $(this).data("type");
    	$(".index_serch_type").html(type);
    	if(type == "全文") {
    		$("#searchform").attr("action","/shop/book/Booksimple/solrList.do");
			$("#searchformMini").attr("action","/shop/book/Booksimple/solrList.do");
	    }else{
		    $("#searchform").attr("action","/shop/book/Booksimple/list.do");
			$("#searchformMini").attr("action","/shop/book/Booksimple/list.do");
	    }
    	
    });
    //全文or关键字 搜索
    $("#header").delegate(".search_btn","click",function(){ 
    	$("#searchform ").submit();
    });
    
    //点击登录退出
	$("#header").delegate('#logoutShow' ,'click', function () {
		$.cookie("userName",null,{path: "/"});
		$.cookie("userIp",null,{path: "/"});
		$.cookie("userAgency",null,{path: "/"});
		$.cookie("userType",null,{path: "/"});
		parent.location.href="http://sso.sciencereading.cn/sso/ssologout?Referer=http://book.sciencereading.cn";
	});

	// 从SSO登录过来的用户（科技云登录的除外），判断SSO登录状态，如果未登录，直接注销
	var ssoUrl = "https://sso.sciencereading.cn/sso/";
	$.getJSON(ssoUrl + "online?callback=?", function(data){
		var ssoLogin = data.Login;
		var userType = $.cookie("userType");
		//if(ssoLogin == false && "sso" == userType){
		if(ssoLogin == false){
			$.cookie("userName",null,{path: "/"});
			$.cookie("userIp",null,{path: "/"});
			$.cookie("userAgency",null,{path: "/"});
			$.cookie("userType",null,{path: "/"});
			$("#userName").text("");
			$("#register").show();
			$("#example").show();
			$("#logoutShow").hide();
			$("#userName").hide();

			/*$.ajax({
				type : "get",
				url : "/shop/main/Login/logout.do",
				dataType : "text",
				async : false,
				success : function(data) {}
			});*/
			//parent.location.href = "/shop/main/Login/sessionReplace.do";
			$.cookie('userName',"科技云",{expires: 1/24/2,path:'/'});
			$.cookie('userIp',"192.168.1.72",{expires: 1/24/2,path:'/'});
			$.cookie('userAgency', "科技云",{expires: 1/24/2,path:'/'});
		}
	});

});     

$(document).ready(function(){
	//加载头文件
	$.ajax({
		type : "get",
		url : "/shop/head1.html",
		dataType : "text",
		async:false,
		cache : true,
		success : function(data) {
			$("#header").html(data); 
		}
		});

	//$("#header").load("/shop/head.html"); 
});

$(function() {
	//刷新导航
    flushHeaderInfo();
    function flushHeaderInfo() {
		var register = $("#register");//注册按钮
		var headerLogin = $("#example");//登陆按钮
		var headerLogout = $("#logoutShow");//退出按钮
		var userName=$("#userName");//退出按钮
		var kjyTxz=$("#kjyTxz");//科技云通行证登陆
		
		//根据IP查是否机构
		$.ajax({
			type:"post",
			url : "/shop/main/Login/checkOrgNameByIp.do",
			dataType : "text",
			async:false,
			success:function(data) {
				data="科技云"
				if(data!=null && data!='' && data!=undefined && data!='null') {
					$("#org_name").text(data + "  您好，欢迎来到科学文库！");
				}
				else {
					$("#org_name").hide();
				}
			}
		})
		
		if($.cookie("userName")!= null && $.cookie("userIp")!=null) {
//			$("#userIp").text($.cookie("userIp"));
			if($.cookie("userAgency") != null && $.cookie("userAgency").length!=0 && $.cookie("userAgency") != "\"\""){
				$("#org_name").show();
				$("#org_name").text($.cookie("userAgency")+ "  您好，欢迎来到科学文库！");
			}else{
				$("#org_name").hide();
			}
			$("#userName").text($.cookie("userName"));
			register.hide();
			headerLogin.hide();
//			kjyTxz.hide();
			headerLogout.show();
			userName.show();
		}
		else {
			$("#userName").text("");
//			$("#userIp").text("");
//			$("#org_name").hide();
			kjyTxz.show();
			register.show();
			headerLogin.show();
			headerLogout.hide();
			userName.hide();
		}
	};
	$("#login_btn").on('click', function () {
		var flag= checkcode();
		if(flag){
			$.ajax({
				type : "post",
   				url : "/shop/main/Login/login.do",
   				dataType : "text",
   				async : false,
   				cache : false,
   				data:{'j_username':$("#txtName").val(),
					  'j_password':$("#txtPwd").val(),
   					  'j_extend_kaptcha':$("#checkcode").val()},
   				success : function(data) { 
   					var reg=/^error/;
					if (data!=null && data!="" && !reg.test(data)) {
						var value=data.split(",");
//						$.cookie('userName',value[1],{expires: 1/24/2,path:'/'});
//						$.cookie('userIp',value[0],{expires: 1/24/2,path:'/'});
//						$.cookie('userAgency', value[2],{expires: 1/24/2,path:'/'});
						window.location.href="/";	
					}
					else {
						data=data.replace(/^error:/,"");
						if(data!='此用户已登录'){
							alert(data);
							changeImage();
						}else{
							window.location.href="/commons/login_failure.jsp";
						}
					}
   				}
   			});
       	 }
	});
	
	//首页点击评语，显示/隐藏功能
	$(".edit_comment_lg").click(function() {
		var status = $(this).data("status");
		if(status == 0) {
			$(this).data("status", 1);
			var comment = $(this).parent().parent().find(".books_lg_recommend_words span").text();
			if(comment.length > 150) {
				comment = comment.substring(0, 147) + "...";
				$(this).parent().parent().find(".books_lg_recommend_words span").text(comment);
			}
			$(this).parent().parent().find(".books_lg_recommend_img").fadeOut(500);
			$(this).parent().parent().find(".books_lg_recommend_words").fadeIn(500);
		}
		else {
			$(this).data("status", 0);
			$(this).parent().parent().find(".books_lg_recommend_img").fadeIn(500);
			$(this).parent().parent().find(".books_lg_recommend_words").fadeOut(500);
		}
	});
	$(".edit_comment_sm").click(function() {
		var status = $(this).data("status");
		if(status == 0) {
			$(this).data("status", 1);
			var comment = $(this).parent().parent().find(".books_sm_recommend_words span").text();
			if(comment.length > 30) {
				comment = comment.substring(0, 27) + "...";
				$(this).parent().parent().find(".books_sm_recommend_words span").text(comment);
			}
			$(this).parent().parent().find(".books_sm_recommend_img").fadeOut(500);
			$(this).parent().parent().find(".books_sm_recommend_words").fadeIn(500);
		}
		else {
			$(this).data("status", 0);
			$(this).parent().parent().find(".books_sm_recommend_img").fadeIn(500);
			$(this).parent().parent().find(".books_sm_recommend_words").fadeOut(500);
		}
	});
	
	$(".books_img_hover").mouseover(function() {
		var content = $(this).parent().parent().find(".books_lg_recommend_words").find("span").html();
		if(content != "") {
			$(this).parent().parent().find(".books_lg_recommend_words").fadeIn(500);
			$(this).parent().parent().find(".books_lg_triangle_img").fadeIn(500);
		}
	});
	$(".books_img_hover").mouseout(function() {
		$(this).parent().parent().find(".books_lg_recommend_words").fadeOut(500);
		$(this).parent().parent().find(".books_lg_triangle_img").fadeOut(500);
	});
});

function checkcode(){
	var checkcode=$('#checkcode').val();
	var name=$('#txtName').val();
	var password=$('#txtPwd').val();
	if((name=='')||(name.length==0)||/^[\s|\u3000]+$/.test(name)){
		alert('邮箱不能为空！');
		return false;
	}
	if((password=='')||(password.length==0)||/^[\s|\u3000]+$/.test(password)){
		alert('密码不能为空！');
		return false;
	}
	if((checkcode=='')||(checkcode.length==0)||/^[\s|\u3000]+$/.test(checkcode)){
		alert('验证码不能为空！');
		return false;
	}
		return true;
}

function changeImage() {
    document.getElementById('kaptchaImage').src ='/kaptcha.jpg'+ '?' + Math.random();
}
function kaptchaImageCreate() {
    document.getElementById('kaptchaImageForCreate').src ='/kaptcha.jpg'+ '?' + Math.random();
}

//QC.Login({
//    btnId:"qq_container"  ,  //插入按钮的节点id
//    scope:"all",
//	size: "C_S"
//});

function qqlogin(){
    QC.Login({}, function (reqData, opts) {//登录成功
        getInfo();
    }, function (opts) {
        //alert('注销成功');
    });
    QC.Login.showPopup({
           appId:"101425435",
           redirectURI:"http://book.sciencereading.cn/shop/main/Login/qqCallbackPage.do"
    });
}

function getInfo() {
    if(QC.Login.check()){
        QC.api("get_user_info",{})
            .success(function(s){//成功回调
                QC.Login.getMe(function(openId, accessToken){
                	var _data={nickname:s.data.nickname,openId:openId};
                    $.ajax({
                        url:"/shop/main/Login/qqLogin.do",
                        type:"POST",
                        data:_data,
                        dataType:'text',
                        success:function(result) {
                        	var reg=/^error/;
        					if (result!=null && result!="" && !reg.test(result)) {
        						//登录成功                                
                                window.location.href=result;
        					}
        					else {
        						window.location.href="/commons/login_failure.jsp";
        					}
                        }
                    });
                })
            })
            .error(function(f){//失败回调
                //alert("获取用户信息失败！登录失败！");
            })
            .complete(function(c){//完成请求回调
            	//alert("获取用户信息完成！");
            });
    }
}



